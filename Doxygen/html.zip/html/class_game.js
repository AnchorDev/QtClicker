var class_game =
[
    [ "Game", "class_game.html#ad59df6562a58a614fda24622d3715b65", null ],
    [ "Buy", "class_game.html#a3f2f9d310dd4c8a4080990938f9c3c8e", null ],
    [ "CheckWorkDone", "class_game.html#a99346ba9253d96b6d14237eab2299aa9", null ],
    [ "GameOver", "class_game.html#aeef0f3e9e8d8f2efeb75c10e1dda4ef2", null ],
    [ "ReadFromFile", "class_game.html#a6aa78cc8269f0fc5d68bf4a48fc61763", null ],
    [ "SaveToFile", "class_game.html#a723b6e1f7befcbc952dfa6b1ef6a8466", null ],
    [ "going", "class_game.html#a71315a9b4f029727c2095326cd93cb18", null ],
    [ "it", "class_game.html#a1ce7c76f43d46d3af471c01a5640d32b", null ],
    [ "j1", "class_game.html#a08bebde38847d0a59e487857d5ca6aab", null ],
    [ "j2", "class_game.html#ab7bb92ac15248a5837c762f1a8b0540e", null ],
    [ "j3", "class_game.html#ade9c187bc2d8cb0cdebd8c48d76ef046", null ],
    [ "j4", "class_game.html#a23524e85582bb72ae5b359d220c54bca", null ],
    [ "j5", "class_game.html#a0b9bf5e4748151a350bf964976f09f99", null ],
    [ "j6", "class_game.html#a22ba6d499f3c8ceb174bbc1964b4ed25", null ],
    [ "j7", "class_game.html#a1b18ebbf5d12934d547bf9e744b16d0d", null ],
    [ "j8", "class_game.html#a29ad887efe7d26ab6825a6f5935596a4", null ],
    [ "jobs", "class_game.html#ad0863958e5f18b47f698ec026d1ae9aa", null ],
    [ "newGame", "class_game.html#a2414785b7b1b0d8ef1d7714ca09b92d9", null ],
    [ "reset", "class_game.html#aa5c4a1a1a96c26db634f6f0355873a5a", null ],
    [ "save", "class_game.html#aee2ca5b7d430e16913f26e155dfefb71", null ],
    [ "start", "class_game.html#a3f91ff1d5c65a349f99bbe6ed373b9e7", null ]
];