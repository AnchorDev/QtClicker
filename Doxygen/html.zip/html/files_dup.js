var files_dup =
[
    [ "QtClicker", "dir_4ff61129a818adece026ed0c6d92f5d9.html", "dir_4ff61129a818adece026ed0c6d92f5d9" ]
];