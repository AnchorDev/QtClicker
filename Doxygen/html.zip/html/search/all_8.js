var searchData=
[
  ['name_0',['name',['../class_job.html#ad962d619ca09173c8c7062e12c6bc8b0',1,'Job']]],
  ['newgame_1',['newGame',['../class_game.html#a2414785b7b1b0d8ef1d7714ca09b92d9',1,'Game']]]
];
