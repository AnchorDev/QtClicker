var searchData=
[
  ['maxlevel_0',['maxLevel',['../class_job.html#a754bccf7fcf4a362521f7f4614a8c33b',1,'Job']]],
  ['money_1',['money',['../main_8cpp.html#a6b51ed6b6ff9f67568931aae0e4d84ca',1,'main.cpp']]]
];
