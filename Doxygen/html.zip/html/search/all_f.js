var searchData=
[
  ['_7eqtclicker_0',['~QtClicker',['../class_qt_clicker.html#a5a3d0445959ffda5c8aebdca31bd9b6f',1,'QtClicker']]]
];
