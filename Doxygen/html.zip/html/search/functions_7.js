var searchData=
[
  ['readfromfile_0',['ReadFromFile',['../class_game.html#a6aa78cc8269f0fc5d68bf4a48fc61763',1,'Game']]],
  ['roundtoint_1',['roundToInt',['../main_8cpp.html#af3104b6e18a5908dc6fd2484da0a0227',1,'main.cpp']]]
];
