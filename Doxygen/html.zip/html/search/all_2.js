var searchData=
[
  ['desc_0',['desc',['../class_job.html#a87b3cf3452611df1b2fa8cb581d2eb9a',1,'Job']]]
];
