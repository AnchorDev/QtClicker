var searchData=
[
  ['save_0',['save',['../class_game.html#aee2ca5b7d430e16913f26e155dfefb71',1,'Game']]],
  ['savetofile_1',['SaveToFile',['../class_game.html#a723b6e1f7befcbc952dfa6b1ef6a8466',1,'Game']]],
  ['seconds_2',['seconds',['../class_job.html#a59eab12f04d9abafef1cc57d624333ea',1,'Job']]],
  ['secondsend_3',['secondsEnd',['../class_job.html#adcf53b937bb70adac47ef8f64042e6a9',1,'Job']]],
  ['secondsstart_4',['secondsStart',['../class_job.html#aa4b8d86fea57e65c38a1f9c3e01a0a2f',1,'Job']]],
  ['start_5',['start',['../class_game.html#a3f91ff1d5c65a349f99bbe6ed373b9e7',1,'Game']]],
  ['starttime_6',['startTime',['../class_job.html#a3ef44e8acf386dbb22eea49ef3f108e9',1,'Job']]]
];
