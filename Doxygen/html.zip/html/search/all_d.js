var searchData=
[
  ['timer_0',['timer',['../class_qt_clicker.html#a7124b6c5ca7246686c8e320cad22bc7e',1,'QtClicker']]],
  ['timetoshow_1',['timeToShow',['../class_job.html#a526ccd3f2237919719032976428f6c6a',1,'Job']]]
];
