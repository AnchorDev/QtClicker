var indexSectionsWithContent =
{
  0: "bcdgijlmnpqrstu~",
  1: "gjmq",
  2: "mq",
  3: "bcgjlmqrs~",
  4: "cdgijlmnprstu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "Wszystko",
  1: "Klasy",
  2: "Pliki",
  3: "Funkcje",
  4: "Zmienne"
};

