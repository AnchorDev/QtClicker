var class_job =
[
    [ "Job", "class_job.html#ad358a8ce05aa34b2540e48235846772b", null ],
    [ "CheckWorkDone", "class_job.html#aefa958fcd4adbd198f5d080565de9f0f", null ],
    [ "LevelUp", "class_job.html#ac63b9e569c4239667245e98f789431f8", null ],
    [ "desc", "class_job.html#a87b3cf3452611df1b2fa8cb581d2eb9a", null ],
    [ "level", "class_job.html#aa4e37c316a8e4856b87a313abba82bb4", null ],
    [ "maxLevel", "class_job.html#a754bccf7fcf4a362521f7f4614a8c33b", null ],
    [ "name", "class_job.html#ad962d619ca09173c8c7062e12c6bc8b0", null ],
    [ "price", "class_job.html#ab3264b8d33c60566e43f8527bf36fa99", null ],
    [ "priceEnd", "class_job.html#a29b1bc7ea4da91c196a7cca790cdd6ae", null ],
    [ "priceStart", "class_job.html#a4854450ab37226ed6e8550f7f4e4eb7a", null ],
    [ "reward", "class_job.html#a62c9365ba05fcd411cb9891ee90b27ad", null ],
    [ "rewardEnd", "class_job.html#a880f87e0b8430ee5872ed7b1d11713a7", null ],
    [ "rewardStart", "class_job.html#ac430a195f4d8ca7628087327155231d6", null ],
    [ "seconds", "class_job.html#a59eab12f04d9abafef1cc57d624333ea", null ],
    [ "secondsEnd", "class_job.html#adcf53b937bb70adac47ef8f64042e6a9", null ],
    [ "secondsStart", "class_job.html#aa4b8d86fea57e65c38a1f9c3e01a0a2f", null ],
    [ "startTime", "class_job.html#a3ef44e8acf386dbb22eea49ef3f108e9", null ],
    [ "timeToShow", "class_job.html#a526ccd3f2237919719032976428f6c6a", null ]
];