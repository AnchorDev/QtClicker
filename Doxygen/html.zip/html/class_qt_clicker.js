var class_qt_clicker =
[
    [ "QtClicker", "class_qt_clicker.html#a9fb5f645e13f8bff64c4e273f40994d4", null ],
    [ "~QtClicker", "class_qt_clicker.html#a5a3d0445959ffda5c8aebdca31bd9b6f", null ],
    [ "timer", "class_qt_clicker.html#a7124b6c5ca7246686c8e320cad22bc7e", null ],
    [ "ui", "class_qt_clicker.html#a9e9998b0af0994f10b12310327ce4c0e", null ]
];