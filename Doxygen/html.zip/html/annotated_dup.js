var annotated_dup =
[
    [ "Game", "class_game.html", "class_game" ],
    [ "Job", "class_job.html", "class_job" ],
    [ "Money", "class_money.html", "class_money" ],
    [ "QtClicker", "class_qt_clicker.html", "class_qt_clicker" ]
];