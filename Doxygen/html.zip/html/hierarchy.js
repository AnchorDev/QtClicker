var hierarchy =
[
    [ "Game", "class_game.html", null ],
    [ "Job", "class_job.html", null ],
    [ "Money", "class_money.html", null ],
    [ "QMainWindow", null, [
      [ "QtClicker", "class_qt_clicker.html", null ]
    ] ]
];